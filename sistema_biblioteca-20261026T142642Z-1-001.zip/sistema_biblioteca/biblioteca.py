import json
from pathlib import Path

# Lista global utilizada para armazenar os livros durante a execução.
livros = []
ARQUIVO = Path(__file__).with_name('livros.json')


def salvar_livros():
    """Salva o acervo no arquivo JSON."""
    try:
        with ARQUIVO.open('w', encoding='utf-8') as arquivo:
            json.dump(livros, arquivo, ensure_ascii=False, indent=4)
    except OSError as erro:
        print(f'Erro ao salvar os livros: {erro}')


def carregar_livros():
    """Carrega os livros já cadastrados ao iniciar o sistema."""
    global livros
    try:
        with ARQUIVO.open('r', encoding='utf-8') as arquivo:
            dados = json.load(arquivo)
        if not isinstance(dados, list) or any(not isinstance(item, dict) for item in dados):
            raise ValueError('Formato inválido de acervo.')
        livros = dados
    except FileNotFoundError:
        livros = []
        salvar_livros()
    except (OSError, json.JSONDecodeError, ValueError) as erro:
        print(f'Não foi possível carregar o arquivo: {erro}')
        print('Verifique o arquivo livros.json antes de continuar.')
        raise SystemExit(1)


def mostrar_livro(livro, numero=None):
    """Mostra as informações de um livro."""
    if numero is not None:
        print(f'\nLivro {numero}')
    print(f"Título: {livro['título']}")
    print(f"Autor: {livro['autor']}")
    print(f"Ano: {livro['ano']}")
    print(f"Disponível: {livro['disponível']}")
    print('-' * 35)


def cadastrar_livro():
    """Solicita os dados e cadastra um novo livro."""
    titulo = input('Título: ').strip()
    autor = input('Autor: ').strip()
    if not titulo or not autor:
        print('Título e autor são obrigatórios.')
        return
    if any(livro['título'].casefold() == titulo.casefold() and
           livro['autor'].casefold() == autor.casefold() for livro in livros):
        print('Este livro já está cadastrado para esse autor.')
        return
    try:
        ano = int(input('Ano de publicação: '))
        if ano < 1 or ano > 2100:
            print('Digite um ano válido entre 1 e 2100.')
            return
    except ValueError:
        print('O ano deve ser um número inteiro.')
        return
    livros.append({'título': titulo, 'autor': autor, 'ano': ano, 'disponível': 'Sim'})
    salvar_livros()
    print('Livro cadastrado com sucesso!')


def listar_livros():
    """Exibe todos os livros cadastrados."""
    if not livros:
        print('Nenhum livro cadastrado.')
        return
    for numero, livro in enumerate(livros, start=1):
        mostrar_livro(livro, numero)


def buscar_livros():
    """Busca livros pelo título ou pelo autor."""
    print('1 - Buscar por título')
    print('2 - Buscar por autor')
    opcao = input('Escolha: ').strip()
    if opcao not in ('1', '2'):
        print('Opção inválida.')
        return
    campo = 'título' if opcao == '1' else 'autor'
    termo = input(f'Digite o {campo}: ').strip().casefold()
    if not termo:
        print('Digite um termo para a busca.')
        return
    encontrados = [livro for livro in livros if termo in livro[campo].casefold()]
    if not encontrados:
        print('Nenhum livro encontrado.')
    else:
        for livro in encontrados:
            mostrar_livro(livro)


def localizar_por_titulo():
    """Localiza um livro pelo título completo."""
    titulo = input('Digite o título completo: ').strip().casefold()
    encontrados = [livro for livro in livros if livro['título'].casefold() == titulo]
    if not encontrados:
        print('Livro não encontrado.')
        return None
    if len(encontrados) == 1:
        return encontrados[0]
    print('Foram encontrados livros com o mesmo título:')
    for numero, livro in enumerate(encontrados, start=1):
        print(f"{numero} - {livro['título']} ({livro['autor']})")
    try:
        escolha = int(input('Escolha o número do livro: '))
        if 1 <= escolha <= len(encontrados):
            return encontrados[escolha - 1]
    except ValueError:
        pass
    print('Seleção inválida.')
    return None


def emprestar_livro():
    """Registra o empréstimo de um livro disponível."""
    livro = localizar_por_titulo()
    if livro is None:
        return
    if livro['disponível'] == 'Não':
        print('Este livro já está emprestado.')
        return
    livro['disponível'] = 'Não'
    salvar_livros()
    print('Empréstimo realizado com sucesso!')


def devolver_livro():
    """Registra a devolução de um livro emprestado."""
    livro = localizar_por_titulo()
    if livro is None:
        return
    if livro['disponível'] == 'Sim':
        print('Este livro já está disponível.')
        return
    livro['disponível'] = 'Sim'
    salvar_livros()
    print('Devolução realizada com sucesso!')


def contar_acervo():
    """Mostra o total de livros disponíveis e emprestados."""
    disponiveis = sum(livro['disponível'] == 'Sim' for livro in livros)
    print(f'Total de livros: {len(livros)}')
    print(f'Disponíveis: {disponiveis}')
    print(f'Emprestados: {len(livros) - disponiveis}')


def ordenar_livros():
    """Lista livros por título ou ano, sem alterar o arquivo."""
    print('1 - Ordem alfabética por título')
    print('2 - Ordem cronológica por ano')
    opcao = input('Escolha: ').strip()
    if opcao == '1':
        ordenados = sorted(livros, key=lambda livro: livro['título'].casefold())
    elif opcao == '2':
        ordenados = sorted(livros, key=lambda livro: livro['ano'])
    else:
        print('Opção inválida.')
        return
    if not ordenados:
        print('Nenhum livro cadastrado.')
    for numero, livro in enumerate(ordenados, start=1):
        mostrar_livro(livro, numero)


def remover_livro():
    """Remove um livro após confirmação do usuário."""
    livro = localizar_por_titulo()
    if livro is None:
        return
    if livro['disponível'] == 'Não':
        print('Não é possível remover um livro emprestado.')
        return
    confirmar = input('Confirma a remoção? (S/N): ').strip().upper()
    if confirmar == 'S':
        livros.remove(livro)
        salvar_livros()
        print('Livro removido com sucesso!')
    else:
        print('Remoção cancelada.')


def menu_principal():
    """Exibe o menu até que o usuário escolha sair."""
    opcoes = {
        '1': cadastrar_livro,
        '2': listar_livros,
        '3': buscar_livros,
        '4': emprestar_livro,
        '5': devolver_livro,
        '6': contar_acervo,
        '7': ordenar_livros,
        '8': remover_livro,
    }
    while True:
        print('\n===== SISTEMA DE BIBLIOTECA =====')
        print('1 - Cadastrar livro')
        print('2 - Listar livros')
        print('3 - Buscar livro')
        print('4 - Emprestar livro')
        print('5 - Devolver livro')
        print('6 - Contador de acervo')
        print('7 - Ordenar livros')
        print('8 - Remover livro')
        print('0 - Sair')
        opcao = input('Escolha uma opção: ').strip()
        if opcao == '0':
            print('Programa encerrado. Até logo!')
            break
        funcao = opcoes.get(opcao)
        if funcao:
            funcao()
        else:
            print('Opção inválida. Tente novamente.')


if __name__ == '__main__':
    carregar_livros()
    menu_principal()
