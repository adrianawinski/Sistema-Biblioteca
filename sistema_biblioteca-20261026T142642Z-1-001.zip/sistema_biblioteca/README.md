# Sistema de Cadastro de Biblioteca

Projeto em Python para gerenciar livros de uma biblioteca por meio de um menu no terminal.

## Funcionalidades

- Cadastro de livros (título, autor, ano e disponibilidade)
- Listagem do acervo e busca por título ou autor
- Empréstimo e devolução com atualização da disponibilidade
- Persistência de dados em `livros.json`
- Extras: contador de acervo, ordenação por título/ano e remoção de livros
- Tratamento de entradas inválidas e confirmação de exclusão

## Como executar

1. Instale Python 3.
2. Mantenha `biblioteca.py` e `livros.json` na mesma pasta.
3. Abra o terminal nessa pasta e execute:

```bash
python biblioteca.py
```

No Windows, se necessário, use `py biblioteca.py`.

## Estrutura

- `biblioteca.py`: funções e menu principal.
- `livros.json`: dados persistidos dos livros; contém cinco livros para testes iniciais.

## Testes sugeridos

1. Liste os cinco livros iniciais.
2. Cadastre um sexto livro e reinicie o programa para conferir a persistência.
3. Busque por parte de um título e pelo nome de um autor.
4. Empreste um livro e confira a alteração para `Não`.
5. Devolva o livro e confira a alteração para `Sim`.
6. Confira o contador, a ordenação e a remoção de um livro disponível.
7. Digite opções inválidas para conferir as mensagens de erro.

## Etapas do projeto

A etapa inicial propôs funções com `pass`; nesta versão final elas já estão implementadas. O `pass` permanece apenas no tratamento de uma escolha numérica inválida, em que a execução continua para a mensagem de erro.
